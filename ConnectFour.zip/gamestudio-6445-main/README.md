https://www.youtube.com/watch?v=1hbCYT6KRuE&feature=youtu.be
https://www.youtube.com/watch?v=Wf5Ayy0csV8&ab_channel=VladoRusn%C3%A1k
https://youtu.be/9FzSxVqPCoY