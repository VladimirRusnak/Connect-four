import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;
import sk.tuke.gamestudio.entity.Comment;
import sk.tuke.gamestudio.service.comment.CommentService;

import java.util.Date;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Configuration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CommentServiceTest.class})
@ComponentScan(basePackages = "sk.tuke.gamestudio.*")
@EntityScan(basePackages = "sk.tuke.gamestudio.*")
class CommentServiceTest {

    @Autowired
    private CommentService commentService;
    private final Random randomGenerator = new Random();

    @Test
    public void addComment() {
        commentService.reset();
        Comment comment = new Comment("Vlado", "connectfour", "This is a comment", new Date());
        commentService.addComment(comment);
        List<Comment> commentList = commentService.getComments("connectfour");
        assertEquals("Vlado", commentList.get(0).getPlayer());
        assertEquals("connectfour", commentList.get(0).getGame());
        assertEquals("This is a comment", commentList.get(0).getComment());
        commentService.reset();
    }
    @Test
    public void getComments() {
        commentService.reset();
        int numberOfComments = randomGenerator.nextInt(5) + 1;
        for  (int i = 0; i < numberOfComments; i++)
            commentService.addComment(new Comment("Vlado" + i, "connectfour", "Vlado" + i, new Date(new Random().nextInt())));
        List<Comment> commentList = commentService.getComments("connectfour");
        assertEquals(numberOfComments, commentList.size());
        for (int i = 0; i < commentList.size() - 1; i++) {
            long diff = commentList.get(i).getCommentedAt().getTime() - commentList.get(i+1).getCommentedAt().getTime();
            assertTrue(diff >= 0);
        }
        commentService.reset();
    }
    @Test
    public void reset() {
        commentService.reset();
        int upperBound = randomGenerator.nextInt(20) + 5;
        for  (int i = 0; i < upperBound; i++)
            commentService.addComment(new Comment("Vlado" + i, "connectfour", "Vlado" + i, new Date()));
        commentService.reset();
        List<Comment> commentList  = commentService.getComments("connectfour");
        assertEquals(0, commentList.size());
    }
}
