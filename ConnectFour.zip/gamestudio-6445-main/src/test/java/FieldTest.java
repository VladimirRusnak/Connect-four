import org.junit.runner.RunWith;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;
import sk.tuke.gamestudio.connectfour.core.Field;
import sk.tuke.gamestudio.connectfour.core.FieldState;
import sk.tuke.gamestudio.connectfour.core.Player;
import sk.tuke.gamestudio.connectfour.core.TileState;
import java.util.Random;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Configuration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CommentServiceTest.class})
@ComponentScan(basePackages = "sk.tuke.gamestudio.*")
@EntityScan(basePackages = "sk.tuke.gamestudio.*")
class FieldTest {

    private final Random randomGenerator = new Random();

    @Test
    public void testSuite() {
        System.out.println("Generating tests...");

        checkFieldGenerate();
        checkGameStateAfterDropDisk(Player.PLAYER1);
        checkGameStateAfterDropDisk(Player.PLAYER2);
        checkGameStateWhenDisksAreConnectedInColumn(Player.PLAYER1);
        checkGameStateWhenDisksAreConnectedInColumn(Player.PLAYER2);
        checkGameStateWhenDisksAreConnectedInRow(Player.PLAYER1);
        checkGameStateWhenDisksAreConnectedInRow(Player.PLAYER2);
        checkGameStateWhenDisksAreConnectedOnDiagonal(Player.PLAYER1);
        checkGameStateWhenDisksAreConnectedOnDiagonal(Player.PLAYER2);

        System.out.println("Test suite was successful!");
    }
    private Field generateField(Player player) {
        int disksForWin = this.randomGenerator.nextInt(6) + 4;
        int rowCount = this.randomGenerator.nextInt(disksForWin) + disksForWin;
        int columnCount = this.randomGenerator.nextInt(disksForWin) + disksForWin;
        return new Field(rowCount, columnCount, disksForWin, player, false);
    }

    private int[] generateTwoDifferentRandomNumbers(Field field) {
        int[] numbs = new int[2];
        numbs[0] = this.randomGenerator.nextInt(field.getColumnCount());
        numbs[1] = this.randomGenerator.nextInt(field.getColumnCount());
        while (numbs[1] == numbs[0])
            numbs[1] = this.randomGenerator.nextInt(field.getColumnCount());
        return numbs;
    }

    private void checkFieldGenerate() {
        Field field = generateField(Player.PLAYER1);
        int rowCount = field.getRowCount();
        int columnCount = field.getColumnCount();

        for (int row = 0; row < rowCount; row++)
            for (int column = 0; column < columnCount; column++)
                assertEquals(TileState.EMPTY, field.getTile(row, column).getTileState(),
                        "Field was not generated properly - Tile should have EMPTY state!");
    }
    private void checkGameStateAfterDropDisk(Player player) {
        Field field = generateField(player);
        int column, i = 0;
        int tilesCount = field.getColumnCount() * field.getColumnCount();
        int[] tileCoordinates = {0, 0};

        while (i++ < tilesCount) {
            column = this.randomGenerator.nextInt(field.getColumnCount());
            //find the tile, which is going to change its state
            for (int row = field.getRowCount() - 1; row >= 0; row--) {
                if (field.getTile(row, column).getTileState() == TileState.EMPTY) {
                    tileCoordinates[0] = row;
                    tileCoordinates[1] = column;
                    break;
                }
            }
            //if dropping disk was successful, check state of the tile
            if (field.dropDisk(column)) {
                if (field.getFieldState() != FieldState.PLAYING && field.getCurrentPlayer() == Player.PLAYER1)
                    assertEquals(TileState.PLAYER1 ,field.getTile(tileCoordinates[0], tileCoordinates[1]).getTileState(),
                        "[checkGameStateAfterDropDisk]" +
                                " Method DropDisk did not function properly - Tile has not changed its state properly!");
                else if(field.getFieldState() != FieldState.PLAYING && field.getCurrentPlayer() == Player.PLAYER2)
                    assertEquals(TileState.PLAYER2, field.getTile(tileCoordinates[0], tileCoordinates[1]).getTileState(),
                            "[checkGameStateAfterDropDisk]" +
                                    " Method DropDisk did not function properly - Tile has not changed its state properly!");
                else if (field.getFieldState() == FieldState.PLAYING && field.getCurrentPlayer() == Player.PLAYER1)
                    assertEquals(TileState.PLAYER2, field.getTile(tileCoordinates[0], tileCoordinates[1]).getTileState(),
                            "[checkGameStateAfterDropDisk]" +
                                    " Method DropDisk did not function properly - Tile has not changed its state properly!");
                else
                    assertEquals(TileState.PLAYER1, field.getTile(tileCoordinates[0], tileCoordinates[1]).getTileState(),
                            "[checkGameStateAfterDropDisk]" +
                                    " Method DropDisk did not function properly - Tile has not changed its state properly!");

                //if the game is finished (DRAW or DECIDED), exit the main loop
                if(field.getFieldState() != FieldState.PLAYING) break;
            }
        }
    }
    private void checkGameStateWhenDisksAreConnectedInColumn(Player player) {
        Field field = generateField(player);
        int[] columns = generateTwoDifferentRandomNumbers(field);
        int disksCount = field.getDisksForWin();

        for (int i = 0; i < disksCount; i++) {
            field.dropDisk(columns[0]);
            field.dropDisk(columns[1]);
        }
        assertEquals(player, field.getWinner(), "[checkGameStateWhenDisksAreConnectedInColumn]" +
                " Checking game state did not function properly - " + player + " should have won!");
    }

    private void checkGameStateWhenDisksAreConnectedInRow(Player player) {
        Field field = generateField(player);
        int columnCount = field.getColumnCount();
        int disksForWin = field.getDisksForWin();
        int columnStart = this.randomGenerator.nextInt(columnCount - disksForWin + 1);

        for (int i = 0; i < disksForWin; i++) {
            field.dropDisk(columnStart + i);
            field.dropDisk(columnStart + i);
        }

        assertEquals(player, field.getWinner(), "[checkGameStateWhenDisksAreConnectedInRow]" +
                " Checking game state did not function properly - " + player + " should have won!");
    }

    private void checkGameStateWhenDisksAreConnectedOnDiagonal(Player player) {
        Field field = generateField(player);
        int column;

        int columnCount = field.getColumnCount();
        int disksForWin = field.getDisksForWin();
        int columnStart = this.randomGenerator.nextInt(columnCount - disksForWin + 1);
        int columnEnd = columnStart + disksForWin;

        column = columnStart;
        while(column < columnEnd) {
            if ((columnEnd - column) % 2 == 0) {
                for (int i = column; i < columnEnd; i++) field.dropDisk(i);
            }
            else {
                for (int i = column; i < columnEnd; i++) field.dropDisk(i);
                field.dropDisk(columnStart);
            }
            column++;
        }

        assertEquals(player, field.getWinner(), "[checkGameStateWhenDisksAreConnectedOnDiagonal]" +
                " Checking game state did not function properly - " + player + " should have won!");
    }
}
