import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;
import sk.tuke.gamestudio.connectfour.core.Field;
import sk.tuke.gamestudio.connectfour.core.GameObject;
import sk.tuke.gamestudio.connectfour.core.Serializator;
import sk.tuke.gamestudio.entity.GameRecord;
import sk.tuke.gamestudio.service.recordgame.GameRecordService;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import java.util.List;

@Configuration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CommentServiceTest.class})
@ComponentScan(basePackages = "sk.tuke.gamestudio.*")
@EntityScan(basePackages = "sk.tuke.gamestudio.*")
class GameRecordTest {

    @Autowired
    private GameRecordService gameRecordService;

    private final Serializator serializator = new Serializator();

    @Test
    public void saveAndLoadGame() {
        String game = "hra";
        gameRecordService.reset(game);
        GameObject gameObject = new GameObject(new Field());
        Date date = new Date();
        GameRecord gameRecord;
        String serialized = serializator.serialize(gameObject);
        for (int i = 0; i < 5; i++) {
            gameRecord = new GameRecord(game, serialized, "hrac1",
                    "hrac2", date);
            gameRecordService.save(gameRecord);
        }
        List<GameRecord> gameRecordList = gameRecordService.load(game, "hrac1", "hrac2");
        for (int i = 0; i < 5; i++) {
            gameRecord = gameRecordList.get(0);
            assertEquals(game, gameRecord.getGame());
            assertEquals(serialized, gameRecord.getSerializedData());
            assertEquals("hrac1", gameRecord.getPlayer1());
            assertEquals("hrac2", gameRecord.getPlayer2());
            assertEquals(date, gameRecord.getRecordedOn());
        }
        gameRecordService.reset(game);
    }

    @Test
    public void reset() {
        String game = "hra";
        gameRecordService.reset(game);
        GameObject gameObject = new GameObject(new Field());
        Date date = new Date();
        GameRecord gameRecord;
        String serialized = serializator.serialize(gameObject);
        for (int i = 0; i < 5; i++) {
            gameRecord = new GameRecord(game, serialized, "hrac1",
                    "hrac2", date);
            gameRecordService.save(gameRecord);
        }
        gameRecordService.reset(game);
        List<GameRecord> gameRecordList = gameRecordService.load(game, "hrac1", "hrac2");
        assertEquals(0, gameRecordList.size());
    }
}
