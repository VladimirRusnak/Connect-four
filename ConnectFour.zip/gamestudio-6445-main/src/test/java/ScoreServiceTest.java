import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;
import sk.tuke.gamestudio.entity.Score;
import sk.tuke.gamestudio.service.score.ScoreService;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Configuration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CommentServiceTest.class})
@ComponentScan(basePackages = "sk.tuke.gamestudio.*")
@EntityScan(basePackages = "sk.tuke.gamestudio.*")
class ScoreServiceTest {

    @Autowired
    private ScoreService scoreService;
    private final Random randomGenerator = new Random();

    @Test
    public void addScore() {
        scoreService.reset();
        int points = randomGenerator.nextInt(5000);
        Date date = new Date();
        scoreService.addScore(new Score("Vlado", "connectfour", points, date));
        scoreService.addScore(new Score("Vlado", "tiles", points, date));
        List<Score> scoreList = scoreService.getTopScore("connectfour");
        assertEquals(1, scoreList.size());
        assertEquals("Vlado", scoreList.get(0).getPlayer());
        assertEquals("connectfour", scoreList.get(0).getGame());
        assertEquals(points, scoreList.get(0).getPoints());
        assertEquals(date, scoreList.get(0).getPlayedAt());
        scoreService.reset();
    }

    @Test
    public void getTopScore() {
        scoreService.reset();
        int[] points = new int[15];
        for  (int i = 0; i < 15; i++) {
            points[i] = randomGenerator.nextInt(5000);
            scoreService.addScore(new Score("Vlado" + i, "connectfour", points[i], new Date()));
        }
        Arrays.sort(points);
        List<Score> scoreList = scoreService.getTopScore("connectfour");
        for (int i = 0; i < 10; i++)
            assertEquals(points[14 - i], scoreList.get(i).getPoints());
        scoreService.reset();
    }

    @Test
    public void reset() {
        scoreService.reset();
        int numberOfEntries = randomGenerator.nextInt(10) + 10;
        for  (int i = 0; i < numberOfEntries; i++)
            scoreService.addScore(new Score("Vlado" + i, "connectfour",
                    randomGenerator.nextInt(5000), new Date()));
        scoreService.reset();
        List<Score> scoreList = scoreService.getTopScore("connectfour");
        assertEquals(0, scoreList.size());
    }

}
