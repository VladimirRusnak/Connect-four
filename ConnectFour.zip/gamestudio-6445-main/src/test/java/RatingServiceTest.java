import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;
import sk.tuke.gamestudio.entity.Rating;
import sk.tuke.gamestudio.service.rating.RatingService;
import java.util.Date;
import java.util.Random;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Configuration
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {CommentServiceTest.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ComponentScan(basePackages = "sk.tuke.gamestudio.*")
@EntityScan(basePackages = "sk.tuke.gamestudio.*")
 class RatingServiceTest {
    @Autowired
    private RatingService ratingService;
    private final Random randomGenerator = new Random();

    @Test
    public void setAndGetRating() {
        ratingService.reset();
        int randomRating, rating;
        for (int i = 0; i < 10; i++) {
            randomRating = randomGenerator.nextInt(5) + 1;
            ratingService.setRating(new Rating("Vlado" + i, "connectfour", randomRating, new Date()));
            rating = ratingService.getRating("connectfour", "Vlado" + i);
            assertEquals(randomRating, rating);
        }
        ratingService.reset();
    }

    @Test
    public void getAverageRating() {
        ratingService.reset();
        int numberOfEntries = randomGenerator.nextInt(5);
        int[] allRatings = new int[numberOfEntries];
        int sum = 0;
        for (int i = 0; i < numberOfEntries; i++) {
            allRatings[i] = randomGenerator.nextInt(5);
            sum += allRatings[i];
            ratingService.setRating(new Rating("Vlado" + i, "connectfour", allRatings[i], new Date()));
        }
        int averageRating = sum / numberOfEntries;
        assertEquals(averageRating, ratingService.getAverageRating("connectfour"));
        ratingService.reset();
    }

    @Test
    public void reset() {
        ratingService.reset();
        int numberOfRatings = randomGenerator.nextInt(11) + 5;
        for  (int i = 0; i < numberOfRatings; i++) {
            ratingService.setRating(new Rating("Vlado" + i, "connectfour",
                    randomGenerator.nextInt(5) + 1, new Date()));
        }
        ratingService.reset();
        int rating = ratingService.getRating("Vlado", "connectfour");
        assertEquals(0, rating);
    }
}
