package sk.tuke.gamestudio.server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import sk.tuke.gamestudio.connectfour.core.FieldState;
import sk.tuke.gamestudio.connectfour.core.GameObject;
import sk.tuke.gamestudio.connectfour.core.Serializator;
import sk.tuke.gamestudio.entity.GameRecord;
import sk.tuke.gamestudio.service.recordgame.GameRecordService;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping
@Scope(WebApplicationContext.SCOPE_SESSION)
public class GameRecordController {
    @Autowired
    private GameRecordService gameRecordService;
    @Autowired
    private PersonController personController;
    @Autowired
    private ConnectFourController connectFourController;

    private List<GameRecord> gameRecordList;

    @RequestMapping("/save_game")
    public String saveGame(Model model) throws ParseException {

        if (connectFourController.getField().getFieldState() != FieldState.PLAYING) {
            return "redirect:/connectfour#gameRecord";
        }

        GameObject gameObject = new GameObject(connectFourController.getField());
        String serializedData = new Serializator().serialize(gameObject);

        String player1 = personController.getPerson1().getLogin();
        String player2 = personController.getPerson2().getLogin();

        gameRecordList = gameRecordService.load("connectfour", player1, player2);
        model.addAttribute("game_saves", gameRecordList);

        GameRecord gameRecord = new GameRecord("connectfour", serializedData, player1,
                player2, new Date());

        gameRecordService.save(gameRecord);
        return "redirect:/connectfour#gameRecord";
    }

    @RequestMapping("/load_games")
    public String loadGames(Model model) {
        String player1 = personController.getPerson1().getLogin();
        String player2 = personController.getPerson2().getLogin();

        gameRecordList = gameRecordService.load("connectfour", player1, player2);
        model.addAttribute("game_saves", gameRecordList);

        return "/load_games";
    }

    @RequestMapping("/load_game")
    public String loadGame(@RequestParam(value = "recordedOn", required = false) String recordedOn) throws ParseException {

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");;
        Date dateFromString = dateFormat.parse(recordedOn);

        for (GameRecord gameRecord : gameRecordList) {
            if (gameRecord.getRecordedOn().getTime() == dateFromString.getTime()) {
                Serializator serializator = new Serializator();
                connectFourController.setFieldFromGameObject((GameObject)
                        serializator.deserialize(gameRecord.getSerializedData()));
            }
        }
        return "redirect:/connectfour";
    }


    @RequestMapping("/delete_save")
    public String deleteSave(@RequestParam(value = "recordedOn", required = false) String recordedOn) throws ParseException {

        String player1 = personController.getPerson1().getLogin();
        String player2 = personController.getPerson2().getLogin();

        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date date = formatter.parse(recordedOn);

        gameRecordService.deleteSave("connectfour", player1, player2, date);

        return "redirect:/load_games";
    }

    public String getDeleteIcon(Date date) {
        StringBuilder stringBuilder = new StringBuilder();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String playDate = dateFormat.format(date);

        stringBuilder.append(String.format("<a href='/delete_save?recordedOn=%s'>\n", playDate));
        stringBuilder.append("<img title = \"Načítať\" alt = \"Načítať\" src = \"/images/delete.png\">\n");
        stringBuilder.append("</a>\n");

        return stringBuilder.toString();
    }

    public String getLoadIcon(Date date) {

        StringBuilder stringBuilder = new StringBuilder();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        String playDate = dateFormat.format(date);

        stringBuilder.append(String.format("<a href='/load_game?recordedOn=%s'>\n", playDate));
        stringBuilder.append("<img title = \"Načítať\" alt = \"Načítať\" src = \"/images/load.png\">\n");
        stringBuilder.append("</a>\n");

        return stringBuilder.toString();
    }

    public String getPlayDate(GameRecord gameRecord) {
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");
        return dateFormat.format(gameRecord.getRecordedOn());
    }

    public boolean isGameRecordListEmpty() {
        return gameRecordList.size() == 0;
    }
}
