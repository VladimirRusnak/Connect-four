package sk.tuke.gamestudio.service.rating;

import sk.tuke.gamestudio.entity.Rating;
import sk.tuke.gamestudio.service.GameStudioException;

import java.sql.*;

public class RatingServiceJDBC implements RatingService{

    public static final String JDBC_URL = "jdbc:postgresql://localhost:5432/gamestudio";
    public static final String JDBC_USER = "postgres";
    public static final String JDBC_PASSWORD = "postgres";
    public static final String DELETE_STATEMENT = "DELETE FROM Rating";
    public static final String SELECT_STATEMENT = "SELECT rating FROM Rating\n" +
            "WHERE game = ? and player = ?;";
    public static final String SET_STATEMENT = """
            INSERT INTO Rating (player, game, rating, rated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT (player, game) DO UPDATE
                SET rating = ?, rated_at = ?;
                """;

    public static final String AVG_STATEMENT = """
                SELECT AVG(rating)
                FROM Rating
                WHERE game = ?;
                """;
    @Override
    public void setRating(Rating rating) throws RatingException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(SET_STATEMENT);
        ) {
            statement.setString(1, rating.getPlayer());
            statement.setString(2, rating.getGame());
            statement.setInt(3, rating.getRating());
            statement.setTimestamp(4, new Timestamp(rating.getRatedAt().getTime()));
            statement.setInt(5, rating.getRating());
            statement.setTimestamp(6, new Timestamp(rating.getRatedAt().getTime()));
            statement.executeUpdate();
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public int getAverageRating(String game) throws RatingException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(AVG_STATEMENT);
        )
        {
            statement.setString(1, game);
            try (ResultSet resultSet = statement.executeQuery()){
                if (!resultSet.next())
                    return 0;
                return resultSet.getInt(1);
            }
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public int getRating(String game, String player) throws RatingException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(SELECT_STATEMENT);
        )
        {
            statement.setString(1, game);
            statement.setString(2, player);
            try (ResultSet resultSet = statement.executeQuery()){
                if (!resultSet.next())
                    return 0;
                return resultSet.getInt(1);
            }
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public void reset() throws RatingException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement statement = connection.createStatement())
        {
            statement.executeUpdate(DELETE_STATEMENT);
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }
}
