package sk.tuke.gamestudio.connectfour.core;

public enum FieldState {
    PLAYING, DRAW, DECIDED, EXITED
}
