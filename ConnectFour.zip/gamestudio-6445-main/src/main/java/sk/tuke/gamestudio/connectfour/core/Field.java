package sk.tuke.gamestudio.connectfour.core;

import java.io.Serializable;
import java.util.Random;

public class Field implements Serializable {

    private final Tile[][] tiles;

    private Player currentPlayer;

    private FieldState fieldState;
    private final int rowCount, columnCount;

    private final int disksForWin;

    private final boolean rotationsOn;
    private int scorePlayer1, scorePlayer2;

    public Field(GameObject gameObject) {
        this.tiles = gameObject.getTiles();
        this.rowCount = gameObject.getRowCount();
        this.columnCount = gameObject.getColumnCount();
        this.disksForWin = gameObject.getDisksForWin();
        this.currentPlayer = gameObject.getCurrentPlayer();
        this.scorePlayer1 = gameObject.getPlayerScore1();
        this.scorePlayer2 = gameObject.getPlayerScore2();
        this.rotationsOn = gameObject.isRotationsOn();
        this.fieldState = FieldState.PLAYING;
    }

    public Field(int rowCount, int columnCount, int disksForWin, Player currentPlayer, boolean rotationsOn) {
        if (rowCount < disksForWin || columnCount < disksForWin)
            throw new IllegalArgumentException("Illegal settings!");

        this.rowCount = rowCount;
        this.columnCount = columnCount;
        this.disksForWin = disksForWin;
        this.currentPlayer = currentPlayer;
        this.fieldState = FieldState.PLAYING;
        this.scorePlayer1 = this.scorePlayer2 = 0;
        this.rotationsOn = rotationsOn;

        this.tiles = new Tile[rowCount][columnCount];
        for (int row = 0; row < this.rowCount; row++)
            for (int column = 0; column < this.columnCount; column++)
                this.tiles[row][column] = new Tile();
    }

    public Field(int rowCount, int columnCount, int disksForWin) {
        this(rowCount, columnCount, disksForWin, Player.PLAYER1, false);
    }

    public Field(int rowCount, int columnCount) {
        this(rowCount, columnCount, 4, Player.PLAYER1, false);
    }

    public Field() { this(6, 7, 4, Player.PLAYER1, false); }

    //drop functions
    public boolean dropDisk(int column) {
        if (getFieldState() != FieldState.PLAYING) return false;
        Tile tile = getLastEmptyTileInColumn(column);
        if (tile == null) return false;
        TileState tileState = tile.getTileState();
        tile.setTileState((this.currentPlayer == Player.PLAYER1) ? TileState.PLAYER1 : TileState.PLAYER2);
        if (this.rotationsOn && (tileState == TileState.ROTL || tileState == TileState.ROTR)) {
            updateGameAfterDrop(column);
            rotate(tileState);
            updateGameAfterRotation(tileState);
        }
        else if (tileState == TileState.EMPTY) {
            updateGameAfterDrop(column);
        }

        if (this.fieldState == FieldState.PLAYING) {
            this.currentPlayer = (this.currentPlayer == Player.PLAYER2) ? Player.PLAYER1 : Player.PLAYER2;
        }
        if (this.rotationsOn) {
            removeAllRotates();
            generateRotate();
        }
        return true;
    }
    private void updateGameAfterDrop(int column) {
        int disksCount = 0;
        int[] maxConnected = getMaxConnected(getRowOfLastDisk(column), column);
        for (int disks: maxConnected) {
            if (disks != 1)
                disksCount += disks;
            if (disks >= this.disksForWin)
                this.fieldState = FieldState.DECIDED;
        }
        if (this.currentPlayer == Player.PLAYER1) {
            if (disksCount == 0)
                this.scorePlayer1 += 10;
            else
                this.scorePlayer1 += (disksCount * 10);
        }
        else {
            if (disksCount == 0)
                this.scorePlayer2 += 10;
            else
                this.scorePlayer2 += (disksCount * 10);
        }
        if (isBoardFilled()) this.fieldState = FieldState.DRAW;
    }

    //rotate functions
    private void rotate(TileState tileState) {
        if (tileState == TileState.ROTL)
            rotateLeft();
        else if (tileState == TileState.ROTR)
            rotateRight();
    }
    private void generateRotate() {
        Random random = new Random();
        if (random.nextInt(3) != 0)
            return;

        if (random.nextInt(2) == 0) generateRotatePosition(TileState.ROTL);
        else generateRotatePosition(TileState.ROTR);
    }
    private void generateRotatePosition(TileState tileState) {
        if (tileState != TileState.ROTL && tileState != TileState.ROTR) return;
        Random random = new Random();
        Tile tile;
        int column;

        do {
            column = random.nextInt(this.columnCount);
            tile = getLastEmptyTileInColumn(column);
        } while (tile == null);
        tile.setTileState(tileState);
    }
    private void updateGameAfterRotation(TileState tileState) {
        if (tileState == TileState.ROTL) updateGameAfterLeftRotation();
        else if (tileState == TileState.ROTR) updateGameAfterRightRotation();
    }
    private void removeAllRotates() {
        for (Tile[] tilesRow: tiles) {
            for (Tile tile : tilesRow) {
                if (tile.getTileState() == TileState.ROTL || tile.getTileState() == TileState.ROTR)
                    tile.setTileState(TileState.EMPTY);
            }
        }
    }

    //left rotate functions
    private void rotateLeft() {
        Tile[] columnArray = new Tile[this.rowCount];
        for (int row = 0; row < this.rowCount; row++)
            columnArray[row] = this.tiles[row][0];

        for (int row = 0; row < this.rowCount; row++)
            for (int column = 0; column < this.columnCount - 1; column++)
                this.tiles[row][column] = this.tiles[row][column + 1];

        for (int row = 0; row < this.rowCount; row++)
            this.tiles[row][this.columnCount - 1] = columnArray[row];
    }
    private void updateGameAfterLeftRotation() {
        updateAfterLeftRotationFirstHalf();
        updateAfterLeftRotationSecondHalf();
    }
    private void updateAfterLeftRotationSecondHalf() {
        int[] maxConnected;
        int scoreP1 = 0, scoreP2 = 0;
        int row = rowCount - 1;
        TileState tileState;
        while (row >= 0 && tiles[row][columnCount - 1].getTileState() != TileState.EMPTY) {
            maxConnected = getMaxConnected(row, columnCount - 1);
            tileState = tiles[row][columnCount - 1].getTileState();
            for (int disks: maxConnected)
                if (disks >= disksForWin) {
                    fieldState = FieldState.DECIDED;
                    break;
                }
            if (tileState == tiles[row][columnCount - 2].getTileState())
                if (tileState == TileState.PLAYER1)
                    scoreP1 += 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 += 10;
            if (row > 0 && tileState == tiles[row - 1][columnCount - 2].getTileState())
                if (tileState == TileState.PLAYER1)
                    scoreP1 += 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 += 10;
            if (row < rowCount - 1 && tileState == tiles[row + 1][columnCount - 2].getTileState())
                if (tileState == TileState.PLAYER1)
                    scoreP1 += 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 += 10;
            row--;
        }
        scorePlayer1 += scoreP1;
        scorePlayer2 += scoreP2;
    }
    private void updateAfterLeftRotationFirstHalf() {
        int scoreP1 = 0, scoreP2 = 0;
        int row = rowCount - 1;
        TileState tileState;
        while (row >= 0 && tiles[row][0].getTileState() != TileState.EMPTY) {
            tileState = tiles[row][0].getTileState();
            if (tileState == tiles[row][columnCount - 1].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 -= 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 -= 10;
            }
            if (row > 0 && tileState == tiles[row - 1][columnCount - 1].getTileState())
                if (tileState == TileState.PLAYER1)
                    scoreP1 -= 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 -= 10;
            if (row < rowCount - 1 && tileState == tiles[row + 1][columnCount - 1].getTileState())
                if (tileState == TileState.PLAYER1)
                    scoreP1 -= 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 -= 10;
            row--;
        }
        scorePlayer1 += scoreP1;
        scorePlayer2 += scoreP2;
    }

    //right rotate functions
    private void rotateRight() {
        Tile[] columnArray = new Tile[this.rowCount];
        for (int row = 0; row < this.rowCount; row++)
            columnArray[row] = this.tiles[row][this.columnCount - 1];

        for (int row = 0; row < this.rowCount; row++)
            for (int column = this.columnCount - 1; column > 0; column--)
                this.tiles[row][column] = this.tiles[row][column - 1];

        for (int row = 0; row < this.rowCount; row++)
            this.tiles[row][0] = columnArray[row];
    }
    private void updateGameAfterRightRotation() {
        updateGameAfterRightRotationFirstHalf();
        updateGameAfterRightRotationSecondHalf();
    }
    private void updateGameAfterRightRotationFirstHalf() {
        int scoreP1 = 0, scoreP2 = 0;
        int row = rowCount - 1;
        TileState tileState;
        while (row >= 0 && tiles[row][columnCount - 1].getTileState() != TileState.EMPTY) {
            tileState = tiles[row][columnCount - 1].getTileState();
            if (tileState == tiles[row][0].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 -= 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 -= 10;
            }
            if (row > 0 && tileState == tiles[row - 1][0].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 -= 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 -= 10;
            }
            if (row < rowCount - 1 && tileState == tiles[row + 1][0].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 -= 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 -= 10;
            }
            row--;
        }
        scorePlayer1 += scoreP1;
        scorePlayer2 += scoreP2;
    }
    private void updateGameAfterRightRotationSecondHalf() {
        int[] maxConnected;
        int scoreP1 = 0, scoreP2 = 0;
        int row = rowCount - 1;
        TileState tileState;
        while (row >= 0 && tiles[row][0].getTileState() != TileState.EMPTY) {
            maxConnected = getMaxConnected(row, 0);
            tileState = tiles[row][0].getTileState();
            for (int disks : maxConnected)
                if (disks >= disksForWin) {
                    fieldState = FieldState.DECIDED;
                    break;
                }
            if (tileState == tiles[row][1].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 += 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 += 10;
            }
            if (row > 0 && tileState == tiles[row - 1][1].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 += 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 += 10;
            }
            if (row < rowCount - 1 && tileState == tiles[row + 1][1].getTileState()) {
                if (tileState == TileState.PLAYER1)
                    scoreP1 += 10;
                else if (tileState == TileState.PLAYER2)
                    scoreP2 += 10;
            }
            row--;
        }
        scorePlayer1 += scoreP1;
        scorePlayer2 += scoreP2;
    }

    //get connected disks functions
    private int[] getMaxConnected(int row, int column) {
        int[] maxConnected = new int[4];
        TileState droppedTileState = this.tiles[row][column].getTileState();
        maxConnected[0] = getMaxConnectedInRow(column, row, droppedTileState);
        maxConnected[1] = getMaxConnectedInColumn(column, row, droppedTileState);
        maxConnected[2] = getMaxConnectedFirstDiagonal(column, row, droppedTileState);
        maxConnected[3] = getMaxConnectedSecondDiagonal(column, row, droppedTileState);;
        return maxConnected;
    }
    private int getMaxConnectedInRow(int column, int row, TileState droppedTileState) {
        int count = 1;
        int column_check = column - 1;

        while(column_check >= 0 && this.tiles[row][column_check].getTileState() == droppedTileState) {
            count++;
            column_check--;
        }
        column_check = column + 1;
        while(column_check < this.columnCount && this.tiles[row][column_check].getTileState() == droppedTileState) {
            count++;
            column_check++;
        }
        return count;
    }
    private int getMaxConnectedInColumn(int column, int row, TileState droppedTileState) {
        int count = 1;
        int row_check = row - 1;

        while(row_check >= 0 && this.tiles[row_check][column].getTileState() == droppedTileState) {
            count++;
            row_check--;
        }
        row_check = row + 1;
        while(row_check < this.rowCount && this.tiles[row_check][column].getTileState() == droppedTileState) {
            count++;
            row_check++;
        }
        return count;
    }
    private int getMaxConnectedFirstDiagonal(int column, int row, TileState droppedTileState) {
        int count = 1;
        int row_check = row - 1;
        int column_check = column - 1;

        while(row_check >= 0 && column_check >= 0 &&
                this.tiles[row_check][column_check].getTileState() == droppedTileState) {
            count++;
            row_check--;
            column_check--;
        }
        row_check = row + 1;
        column_check = column + 1;
        while(row_check < this.rowCount && column_check < this.columnCount &&
                this.tiles[row_check][column_check].getTileState() == droppedTileState) {
            count++;
            row_check++;
            column_check++;
        }
        return count;
    }
    private int getMaxConnectedSecondDiagonal(int column, int row, TileState droppedTileState) {
        int count = 1;
        int row_check = row - 1;
        int column_check = column + 1;

        while(row_check >= 0 && column_check < this.columnCount &&
                this.tiles[row_check][column_check].getTileState() == droppedTileState) {
            count++;
            row_check--;
            column_check++;
        }
        column_check = column - 1;
        row_check = row + 1;
        while(row_check < this.rowCount && column_check >= 0 &&
                this.tiles[row_check][column_check].getTileState() == droppedTileState) {
            count++;
            row_check++;
            column_check--;
        }
        return count;
    }

    //check field functions
    private boolean isBoardFilled() {
        for (int column = 0; column < this.columnCount; column++)
            if (this.tiles[0][column].getTileState() == TileState.EMPTY)
                return false;
        return true;
    }
    private int getRowOfLastDisk(int column) {
        int row = 0;
        while(row < this.rowCount && this.tiles[row][column].getTileState() != TileState.PLAYER1
                && this.tiles[row][column].getTileState() != TileState.PLAYER2) {
            row++;
        }
        return row;
    }
    private Tile getLastEmptyTileInColumn(int column) {
        if (column >= this.columnCount) return null;
        int row = getRowOfLastDisk(column) - 1;
        if (row < 0) return null;
        return this.tiles[row][column];
    }

    public int getRowCount() {
        return rowCount;
    }
    public int getColumnCount() {
        return columnCount;
    }
    public Tile getTile(int row, int column) {
        return tiles[row][column];
    }
    public Player getCurrentPlayer() {
        return currentPlayer;
    }
    public Player getWinner() {
        if (fieldState == FieldState.DECIDED) return currentPlayer;
        return null;
    }
    public FieldState getFieldState() {
        return this.fieldState;
    }
    public int getDisksForWin() {
        return disksForWin;
    }
    public int getScorePlayer1() {
        return scorePlayer1;
    }
    public int getScorePlayer2() {
        return scorePlayer2;
    }

    public boolean getRotationsOn() {return rotationsOn;}
    public void exitGame() { this.fieldState = FieldState.EXITED;}
    Tile[][] getTiles() {return this.tiles;}
}
