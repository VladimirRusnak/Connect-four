package sk.tuke.gamestudio.service.recordgame;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;
import sk.tuke.gamestudio.entity.Comment;
import sk.tuke.gamestudio.entity.GameRecord;
import sk.tuke.gamestudio.entity.Rating;
import sk.tuke.gamestudio.service.rating.RatingException;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Objects;

public class GameRecordServiceRestClient implements GameRecordService{

    private final String url = "http://localhost:8080/api/gamerecord";

    @Autowired
    private RestTemplate restTemplate;

    @Override
    public void save(GameRecord gameRecord) throws GameRecordException {
        if (gameRecord != null)
            restTemplate.postForEntity(url, gameRecord, GameRecord.class);
    }

    @Override
    public List<GameRecord> load(String game, String player1, String player2) throws GameRecordException {
        return Arrays.asList(Objects.requireNonNull(restTemplate.getForEntity
                (url + "/" + game + "/" + player1 + "/" + player2, GameRecord[].class).getBody()));
    }

    @Override
    public void deleteSave(String game, String player1, String player2, Date recordedOn) throws GameRecordException {
        throw new UnsupportedOperationException("Reset is not supported on web interface!");
    }

    @Override
    public void reset(String game) throws RatingException {
        throw new UnsupportedOperationException("Reset is not supported on web interface!");
    }
}
