package sk.tuke.gamestudio.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@NamedQuery( name = "GameRecord.getRecordsForPlayers",
        query = "SELECT gr FROM GameRecord gr WHERE gr.game = :game AND (gr.player1 = :player1" +
                " AND gr.player2 = :player2) OR (gr.player1 = :player2 AND gr.player2 = :player1)" +
                " ORDER BY gr.recordedOn DESC")
@NamedQuery( name = "GameRecord.resetGameRecord",
        query = "DELETE FROM GameRecord WHERE game = :game")
@NamedQuery( name = "GameRecord.deleteGameRecord",
        query = "DELETE FROM GameRecord WHERE game = :game AND player1 = :player1 AND player2 = :player2" +
                " AND recordedOn = :recordedOn")
@Entity
@Table(name = "GameRecord")
public class GameRecord implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "record_id")
    private int recordID;
    @Column(name = "serialized_data", length = 10000)
    private String serializedData;
    @Column(name = "game")
    private String game;
    @Column(name = "player_1")
    private String player1;
    @Column(name = "player_2")
    private String player2;
    @Column(name = "recorded_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date recordedOn;

    public GameRecord() {}
    public GameRecord(String game, String serializedData, String player1, String player2, Date recordedOn) {
        this.game = game;
        this.player1 = player1;
        this.player2 = player2;
        this.serializedData = serializedData;
        this.recordedOn = recordedOn;
    }

    public String getGame() {
        return game;
    }

    public void setGame(String game) {
        this.game = game;
    }

    public String getPlayer1() {
        return player1;
    }

    public void setPlayer1(String player) {
        this.player1 = player;
    }

    public String getPlayer2() {
        return player2;
    }

    public void setPlayer2(String player) {
        this.player2 = player;
    }

    public String getSerializedData() {
        return serializedData;
    }

    public void setSerializedData(String serializedData) {
        this.serializedData = serializedData;
    }

    public Date getRecordedOn() {
        return recordedOn;
    }

    public void setRecordedOn(Date recordedOn) {
        this.recordedOn = recordedOn;
    }

    @Override
    public String toString() {
        return "GameRecord{" +
                "recordID=" + recordID +
                ", game='" + game + '\'' +
                ", player1='" + player1 + '\'' +
                ", player2='" + player2 + '\'' +
                ", serialized=" + serializedData +
                ", recordedOn=" + recordedOn +
                '}';
    }
}
