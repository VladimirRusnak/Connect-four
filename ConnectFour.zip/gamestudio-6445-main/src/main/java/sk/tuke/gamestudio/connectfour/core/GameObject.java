package sk.tuke.gamestudio.connectfour.core;

import java.io.Serializable;

public class GameObject implements Serializable {
    private final Tile[][] tiles;
    private final Player currentPlayer;
    private boolean rotationsOn;
    private final int disksForWin;
    private final int rowCount, columnCount;

    private final int playerScore1, playerScore2;

    public GameObject(Field field) {
        this.tiles = field.getTiles();
        this.currentPlayer = field.getCurrentPlayer();
        this.rotationsOn = field.getRotationsOn();
        this.disksForWin = field.getDisksForWin();
        this.rowCount = field.getRowCount();
        this.columnCount = field.getColumnCount();
        this.playerScore1 = field.getScorePlayer1();
        this.playerScore2 = field.getScorePlayer2();
    }

    public Tile[][] getTiles() {
        return tiles;
    }

    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    public boolean isRotationsOn() {
        return rotationsOn;
    }

    public void setRotationsOn(boolean rotationsOn) {
        this.rotationsOn = rotationsOn;
    }

    public int getDisksForWin() {
        return disksForWin;
    }

    public int getRowCount() {
        return rowCount;
    }

    public int getColumnCount() {
        return columnCount;
    }

    public int getPlayerScore1() {
        return playerScore1;
    }

    public int getPlayerScore2() {
        return playerScore2;
    }
}
