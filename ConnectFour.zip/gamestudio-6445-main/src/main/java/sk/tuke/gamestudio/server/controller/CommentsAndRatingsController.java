package sk.tuke.gamestudio.server.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import sk.tuke.gamestudio.connectfour.core.Player;
import sk.tuke.gamestudio.entity.Comment;
import sk.tuke.gamestudio.entity.Person;
import sk.tuke.gamestudio.entity.Rating;
import sk.tuke.gamestudio.service.comment.CommentService;
import sk.tuke.gamestudio.service.rating.RatingService;

import java.util.*;

@Controller
@RequestMapping
@Scope(WebApplicationContext.SCOPE_SESSION)
public class CommentsAndRatingsController {
    @Autowired
    private PersonController personController;
    @Autowired
    private CommentService commentService;
    @Autowired
    private RatingService ratingService;
    private List<String> players;

    @RequestMapping("/add_comment")
    public String addComment(@RequestParam(value = "comment1", required = false) String comment1,
                             @RequestParam(value = "comment2", required = false) String comment2) {
        if (comment1 != null && comment1.length() != 0) {
            commentService.addComment(new Comment(personController.getPerson1().getLogin(),
                    "connectfour", comment1, new Date()));
        }

        if (comment2 != null && comment2.length() != 0) {
            commentService.addComment(new Comment(personController.getPerson2().getLogin(),
                    "connectfour", comment2, new Date()));
        }

        return "redirect:/connectfour#mainDiv";
    }

    @RequestMapping("/set_rating")
    public String setRating(@RequestParam(value = "rating1", required = false) Integer rating1,
                            @RequestParam(value = "rating2", required = false) Integer rating2) {
        if (rating1 != null) {
            ratingService.setRating(new Rating(personController.getPerson1().getLogin(),
                    "connectfour", rating1, new Date()));
        }

        if (rating2 != null) {
            ratingService.setRating(new Rating(personController.getPerson2().getLogin(),
                    "connectfour", rating2, new Date()));
        }

        return "redirect:/connectfour#mainDiv";
    }

    @RequestMapping("/comments_and_ratings")
    public String commentsAndRatings(Model model) {
        List<Comment> commentList = commentService.getComments("connectfour");
        model.addAttribute("comments", commentList);

        players = new ArrayList<>();
        for (Comment comment : commentList) {
            if (!players.contains(comment.getPlayer()) &&
                    ratingService.getRating("connectfour", comment.getPlayer()) != 0) {
                players.add(comment.getPlayer());
            }
        }

        model.addAttribute("players", players);
        return "comments_and_ratings";
    }

    public String getRating(String player) {
        return String.valueOf(ratingService.getRating("connectfour", player));
    }

    public CommentService getCommentService() {
        return commentService;
    }


    public RatingService getRatingService() {
        return ratingService;
    }

    public int getAverageRating() {
        return ratingService.getAverageRating("connectfour");
    }

    public boolean isCommentListEmpty() {
        return commentService.getComments("connectfour").size() == 0;
    }

    public boolean isRatingListEmpty() {
        return players.size() == 0;
    }
}
