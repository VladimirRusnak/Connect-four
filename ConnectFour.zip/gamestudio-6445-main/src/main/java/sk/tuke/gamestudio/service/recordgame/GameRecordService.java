package sk.tuke.gamestudio.service.recordgame;

import sk.tuke.gamestudio.entity.GameRecord;

import java.util.Date;
import java.util.List;

public interface GameRecordService {
    void save(GameRecord gameRecord) throws GameRecordException;
    List<GameRecord> load(String game, String player1, String player2) throws GameRecordException;

    void deleteSave(String game, String player1, String player2, Date recordedOn) throws GameRecordException;

    void reset(String game) throws GameRecordException;
}
