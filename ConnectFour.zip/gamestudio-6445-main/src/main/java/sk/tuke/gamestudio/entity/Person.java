package sk.tuke.gamestudio.entity;

import com.sun.istack.NotNull;

import javax.persistence.*;
import java.io.Serializable;

@NamedQuery( name = "Person.getPerson",
        query = "SELECT u FROM Person u WHERE u.game = :game AND u.login = :login")
@NamedQuery( name = "Person.resetPersons",
        query = "DELETE FROM Person")
@Entity
@Table(name = "Person")
public class Person implements Serializable {
    @Id
    private String login;
    @Id
    private String game;
    @NotNull
    private String password;

    Person() {}

    public Person(String login, String password, String game) {
        this.login = login;
        this.password = password;
        this.game = game;
    }

    @Override
    public String toString() {
        return "Person{" +
                "login='" + login + '\'' +
                ", password='" + password + '\'' +
                ", game='" + game + '\'' +
                '}';
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGame() {
        return game;
    }

    public void setGame(String game) {
        this.game = game;
    }
}
