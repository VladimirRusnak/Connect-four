package sk.tuke.gamestudio.entity;

import javax.persistence.*;
import java.util.Date;
@NamedQuery( name = "Comment.getComments",
        query = "SELECT s FROM Comment s WHERE s.game = :game ORDER BY s.commentedAt DESC")
@NamedQuery( name = "Comment.resetComments",
        query = "DELETE FROM Comment")
@Entity
@Table(name = "Comment")
public class Comment{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int commentID;
    private String player;
    private String game;
    private String comment;
    private Date commentedAt;

    public Comment() {}
    public Comment(String player, String game, String comment, Date commentedAt) {
        this.player = player;
        this.game = game;
        this.comment = comment;
        this.commentedAt = commentedAt;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public String getGame() {
        return game;
    }

    public void setGame(String game) {
        this.game = game;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Date getCommentedAt() {
        return commentedAt;
    }

    public void setCommentedAt(Date commentedAt) {
        this.commentedAt = commentedAt;
    }

    public int getCommentID() {
        return commentID;
    }

    public void setCommentID(int commentID) {
        this.commentID = commentID;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "player='" + player + '\'' +
                ", game='" + game + '\'' +
                ", comment='" + comment + '\'' +
                ", commentedOn=" + commentedAt +
                '}';
    }
}
