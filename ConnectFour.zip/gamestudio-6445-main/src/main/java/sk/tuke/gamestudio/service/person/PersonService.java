package sk.tuke.gamestudio.service.person;

import sk.tuke.gamestudio.entity.Person;

public interface PersonService {
    void registerPerson(String login, String password, String game) throws PersonException;
    Person getPerson(String login, String game) throws PersonException;
    void reset() throws PersonException;
}
