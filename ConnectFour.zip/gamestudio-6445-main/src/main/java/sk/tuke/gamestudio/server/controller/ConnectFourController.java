package sk.tuke.gamestudio.server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.WebApplicationContext;
import sk.tuke.gamestudio.connectfour.core.*;
import sk.tuke.gamestudio.entity.Score;
import sk.tuke.gamestudio.service.score.ScoreService;

import java.util.Date;


@Controller
@RequestMapping
@Scope(WebApplicationContext.SCOPE_SESSION)
public class ConnectFourController {
    @Autowired
    private ScoreService scoreService;
    @Autowired
    private PersonController personController;
    private Field field;
    private String color1, color2;
    private boolean sameColors;

    private int row, column;

    public ConnectFourController() {
        this.field = new Field();
        this.row = 6;
        this.column = 7;
    }

    @RequestMapping("/set_color_first_player")
    public String setColor1(@RequestParam(value = "color", required = false) String color) {
        sameColors = false;
        if (this.color2.equals(color)) {
            sameColors = true;
            return "redirect:/connectfour#mainDiv";
        }
        this.color1 = color;
        return "redirect:/connectfour#mainDiv";
    }

    @RequestMapping("/set_color_second_player")
    public String setColor2(@RequestParam(value = "color", required = false) String color) {
        sameColors = false;
        if (this.color1.equals(color)) {
            sameColors = true;
            return "redirect:/connectfour#mainDiv";
        }
        this.color2 = color;
        return "redirect:/connectfour#mainDiv";
    }

    @RequestMapping("/connectfour")
    public String connectfour(@RequestParam(value = "column", required = false) Integer column,
                              Model model) {
        fillModel(model);

        if (color1 == null) {
            color1 = "red";
        }
        if (color2 == null) {
            color2 = "yellow";
        }

        if (column != null) {
            sameColors = false;
            if (field.getFieldState() == FieldState.PLAYING) {
                field.dropDisk(column);
                if (field.getFieldState() == FieldState.DECIDED && personController.isLogged()) {
                    if (field.getWinner() == Player.PLAYER1) {
                        scoreService.addScore(new Score(personController.getPerson1().getLogin(),
                                "connectfour", field.getScorePlayer1(), new Date()));
                    } else if (field.getWinner() == Player.PLAYER2) {
                        scoreService.addScore(new Score(personController.getPerson2().getLogin(),
                                "connectfour", field.getScorePlayer2(), new Date()));
                    }
                }
            }
            return "redirect:/connectfour";
        }
        return "connectfour"; //same name as the template
    }

    @RequestMapping("/create_field")
    public String createField(@RequestParam(value = "row", required = false) Integer row,
                            @RequestParam(value = "column", required = false) Integer column) {
        this.row = row;
        this.column = column;
        this.field = new Field(row, column);
        return "redirect:/connectfour#mainDiv";
    }

    @RequestMapping("/create_field_with_rotations")
    public String createField() {
        this.field = new Field(row, column, 4, Player.PLAYER1, true);
        return "redirect:/connectfour#mainDiv";
    }

    private void fillModel(Model model) {
        model.addAttribute("scores", scoreService.getTopScore("connectfour"));
        model.addAttribute("htmlField", getHtmlField());
    }
    private String getHtmlField() {
        StringBuilder sb = new StringBuilder();
        sb.append("<table id =\"field\">\n");
        for (int row = 0; row < field.getRowCount(); row++) {
            sb.append("<tr>\n");
            for (int column = 0; column < field.getColumnCount(); column++) {
                sb.append("<td>\n");
                sb.append(String.format("<a href='/connectfour?column=%d#mainDiv' class = \"tile\">\n", column));
                sb.append("<img src='/images/").append(getTileImage(row, column));
                sb.append("</a>\n");
                sb.append("</td>\n");
            }
            sb.append("</tr>\n");
        }
        sb.append("</table>\n");
        return sb.toString();
    }

    public String getTileImage(int row, int column) {
        if (field.getTile(row, column).getTileState() == TileState.PLAYER1) {
            return "tile_" + color1 + ".png'>\n";
        } else if (field.getTile(row, column).getTileState() == TileState.PLAYER2) {
            return "tile_" + color2 + ".png'>\n";
        } else if (field.getTile(row, column).getTileState() == TileState.ROTL) {
            return "tile_shift_left.jpg'>\n";
        } else if (field.getTile(row, column).getTileState() == TileState.ROTR) {
            return "tile_shift_right.jpg'>\n";
        }
        return "tile.png'>\n";
    }

    public void setFieldFromGameObject(GameObject gameObject) {
        field = new Field(gameObject);
    }
    public String getColor1Image() {
        return "<img class='playerColor' src='/images/colors/" + color1 + ".png'>\n";
    }

    public String getColor2Image() {
        return "<img class='playerColor' src='/images/colors/" + color2 + ".png'>\n";
    }

    public boolean areSameColors() {
        return sameColors;
    }

    public String getScore1() {
        return String.valueOf(field.getScorePlayer1());
    }

    public String getScore2() {
        return String.valueOf(field.getScorePlayer2());
    }

    public String getColor1() {
        return color1;
    }

    public String getColor2() {
        return color2;
    }

    public Field getField() {
        return field;
    }
}
