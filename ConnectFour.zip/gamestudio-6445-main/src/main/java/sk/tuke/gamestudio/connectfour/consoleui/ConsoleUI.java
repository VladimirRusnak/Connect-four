package sk.tuke.gamestudio.connectfour.consoleui;

import org.springframework.beans.factory.annotation.Autowired;
import sk.tuke.gamestudio.connectfour.core.*;
import sk.tuke.gamestudio.entity.Comment;
import sk.tuke.gamestudio.entity.GameRecord;
import sk.tuke.gamestudio.entity.Rating;
import sk.tuke.gamestudio.entity.Score;
import sk.tuke.gamestudio.service.comment.CommentService;
import sk.tuke.gamestudio.service.rating.RatingService;
import sk.tuke.gamestudio.service.recordgame.GameRecordService;
import sk.tuke.gamestudio.service.score.ScoreService;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConsoleUI  {

    private Field field;
    private String colorP1, colorP2;
    private String backgroundP1, backgroundP2;

    private String nameP1, nameP2;

    @Autowired
    private ScoreService scoreService;
    @Autowired
    private CommentService commentService;
    @Autowired
    private RatingService ratingService;
    @Autowired
    private GameRecordService gameRecordService;

    public ConsoleUI(Field field) {
        this.field = field;
    }
    public void play() {
        int input;
            title();
        commentsAndRatings();
        gameHeader();
        getPlayersNames();
        getPlayersColors();
        savedGames();
        boolean enableDroppingDisk = getDecision(droppingDiskRequest());
        do {
            showGame();
            input = handleFieldInput();
            if (input == 0) {
                field.exitGame();
                break;
            }
            if (enableDroppingDisk) showDroppingDisk(input - 1);
            field.dropDisk(input - 1);
        } while (field.getFieldState() == FieldState.PLAYING);
        if (input != 0) showGame();
        showFinalGameState();
        if (field.getFieldState() == FieldState.EXITED)
            saveGame();
        hallOfFame();
        rateGame();
        commentGame();
    }

    //games saving functions
    private void savedGames() {
        List<GameRecord> gameRecordList = gameRecordService.load("connectfour", nameP1, nameP2);
        if (gameRecordList.size() != 0) {
            boolean repeat;
            do {
                printSavedGames(gameRecordList);
                repeat = handleSavedGamesInput(gameRecordList);
                gameRecordList = gameRecordService.load("connectfour", nameP1, nameP2);
            } while(repeat && gameRecordList.size() != 0);
        }
    }
    private void printSavedGames(List<GameRecord> gameRecordList) {
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy H:mm");
        System.out.println(Colors.YELLOW_BOLD.color +
                "\n█▀ ▄▀█ █░█ █▀▀ █▀▄   █▀▀ ▄▀█ █▀▄▀█ █▀▀ █▀\n" +
                "▄█ █▀█ ▀▄▀ ██▄ █▄▀   █▄█ █▀█ █░▀░█ ██▄ ▄█\n" + Colors.DEFAULT.color);
        GameRecord gameRecord;
        int gamesCount = gameRecordList.size();
        for(int game = 0; game < gamesCount; game++) {
            gameRecord = gameRecordList.get(game);
            System.out.print(Colors.YELLOW_BOLD.color + (game + 1) + ". " + Colors.DEFAULT.color);
            System.out.print(Colors.YELLOW.color + nameP1 + ", " + nameP2 + " [");
            System.out.print(Colors.CYAN.color + dateFormat.format(gameRecord.getRecordedOn()));
            System.out.println(Colors.YELLOW.color + "]");
        }
    }
    private void askForGamesInput() {
        System.out.print(Colors.CYAN.color + "Which game would you like to load? (NUM x to delete, ENTER to skip) " + Colors.DEFAULT.color);
    }
    private boolean handleSavedGamesInput(List<GameRecord> gameRecordList) {
        Pattern pattern = Pattern.compile("^(\\d)$|^(\\d)( )*(x)$|^$");
        int input, gamesCount = gameRecordList.size();
        boolean isInputValid = false;
        Scanner scanner = new Scanner(System.in);
        do {
            askForGamesInput();
            String text = scanner.nextLine();
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                if (matcher.group(0).length() == 0) {
                    isInputValid = true;
                } else {
                    if (matcher.group(4) != null) {
                        input = Integer.parseInt(matcher.group(2));
                        if (input >= 1 && input <= gamesCount) {
                            deleteGame(gameRecordList.get(input - 1));
                            return true;
                        }
                    } else {
                        input = Integer.parseInt(matcher.group(1));
                        if (input >= 1 && input <= gamesCount) {
                            loadGame(gameRecordList.get(input - 1));
                            isInputValid = true;
                        }
                    }
                }
            }
            else {
                System.out.println(Colors.RED.color + "Invalid input!" + Colors.DEFAULT.color);
            }
        } while (!isInputValid);
        return false;
    }
    private void deleteGame(GameRecord gameRecord) {
        gameRecordService.deleteSave(gameRecord.getGame(), gameRecord.getPlayer1(), gameRecord.getPlayer2(), gameRecord.getRecordedOn());
    }
    private void loadGame(GameRecord gameRecord) {
        Serializator serializator = new Serializator();
        GameObject gameObject = (GameObject) serializator.deserialize(gameRecord.getSerializedData());
        setField(new Field(gameObject));
    }
    private void saveGame() {
        boolean decision = getDecision(savingGameRequest());
        if (decision) {
            GameObject gameObject = new GameObject(field);
            Serializator serializator = new Serializator();
            String serializedData = serializator.serialize(gameObject);
            gameRecordService.save(new GameRecord("connectfour", serializedData, nameP1
                    , nameP2, new Date()));
        }
    }

    //show and print functions
    private void title() {
        System.out.println(
                Colors.YELLOW_BOLD.color + "\t\t\t\t\t░█▀▀░█▀█░█▀█░█▀█░█▀▀░█▀▀░▀█▀░\t"+Colors.RED_BOLD.color+"█▀▀░█▀█░█░█░█▀▄\n" +
                        Colors.YELLOW_BOLD.color + "\t\t\t\t\t░█░░░█░█░█░█░█░█░█▀▀░█░░░░█░░\t"+Colors.RED_BOLD.color+"█▀▀░█░█░█░█░█▀▄\n" +
                        Colors.YELLOW_BOLD.color + "\t\t\t\t\t░▀▀▀░▀▀▀░▀░▀░▀░▀░▀▀▀░▀▀▀░░▀░░\t"+Colors.RED_BOLD.color+"▀░░░▀▀▀░▀▀▀░▀░▀\n" +
                        Colors.YELLOW_BOLD.color + "\t\t\t\t\t-----------------------------\t"+Colors.RED_BOLD.color+"---------------" +
                        Colors.DEFAULT.color);
    }
    private void gameHeader() {
        System.out.println( Colors.YELLOW_BOLD.color +
                "\n" +
                "█▀▀ ▄▀█ █▀▄▀█ █▀▀\n" +
                "█▄█ █▀█ █░▀░█ ██▄\n" + Colors.DEFAULT.color);
    }
    private void printAllColors() {
        System.out.println(Colors.DEFAULT.color);
        System.out.println("1 " + Colors.BLACK.color + "BLACK\t\t" + BackgroundColors.BLACK.color + "  " + Colors.DEFAULT.color);
        System.out.println("2 " + Colors.RED.color + "RED\t\t" + BackgroundColors.RED.color + "  " + Colors.DEFAULT.color);
        System.out.println("3 " + Colors.GREEN.color + "GREEN\t\t" + BackgroundColors.GREEN.color + "  " + Colors.DEFAULT.color);
        System.out.println("4 " + Colors.YELLOW.color + "YELLOW\t" + BackgroundColors.YELLOW.color + "  " + Colors.DEFAULT.color);
        System.out.println("5 " + Colors.BLUE.color + "BLUE\t\t" + BackgroundColors.BLUE.color + "  " + Colors.DEFAULT.color);
        System.out.println("6 " + Colors.PURPLE.color + "PURPLE\t" + BackgroundColors.PURPLE.color + "  " + Colors.DEFAULT.color);
        System.out.println("7 " + Colors.WHITE.color + "WHITE\t\t" + BackgroundColors.WHITE.color + "  " + Colors.DEFAULT.color);
        System.out.println();
    }
    private void printAskForFieldInput() {
        if (field.getCurrentPlayer() == Player.PLAYER1) {
            System.out.print(Colors.CYAN.color + "Please, " + colorP1 +
                    nameP1 + Colors.CYAN.color + " choose the column (0 for exit): " + Colors.DEFAULT.color);
        }
        else {
            System.out.print(Colors.CYAN.color + "Please, " + colorP2 +
                    nameP2 + Colors.CYAN.color + " choose the column (0 for exit): " + Colors.DEFAULT.color);
        }
    }
    private void showFinalGameState() {
        if (field.getFieldState() == FieldState.DRAW)
            draw();
        else if (field.getFieldState() == FieldState.DECIDED) {
            decided();
            if (field.getWinner() == Player.PLAYER1)
                scoreService.addScore(new Score(nameP1, "connectfour", field.getScorePlayer1(), new Date()));
            else if(field.getWinner() == Player.PLAYER2)
                scoreService.addScore(new Score(nameP2, "connectfour", field.getScorePlayer2(), new Date()));
        }
        else if (field.getFieldState() == FieldState.EXITED)
            exited();
    }

    //print field functions
    private void showGame() {
        printScore();
        printColumnHeader(field.getColumnCount());
        printFieldBody(field.getRowCount(), field.getColumnCount());
    }
    private void printFieldBody(int rowCount, int columnCount) {
        for (int row = 0; row < rowCount; row++) {
            printUpperPartOfRow(columnCount);
            printMiddlePartOfRow(columnCount, row);
            printLowerPartOfRow(columnCount, row);
        }
    }
    private void printUpperPartOfRow(int columnCount) {
        for (int column = 0; column < columnCount; column++)
            System.out.print("\t\t ___ ");
        System.out.println();
    }
    private void printMiddlePartOfRow(int columnCount, int row) {
        for (int column = 0; column < columnCount; column++) {
            if (field.getTile(row, column).getTileState() == TileState.PLAYER1)
                System.out.print("\t\t" + backgroundP1 + "|   |"+ Colors.DEFAULT.color);
            else if (field.getTile(row, column).getTileState() == TileState.PLAYER2)
                System.out.print("\t\t" + backgroundP2 + "|   |"+ Colors.DEFAULT.color);
            else if (field.getTile(row, column).getTileState() == TileState.ROTL)
                System.out.print("\t\t|" + Colors.CYAN.color + "<<<" + Colors.DEFAULT.color+ "|");
            else if (field.getTile(row, column).getTileState() == TileState.ROTR)
                System.out.print("\t\t|" + Colors.CYAN.color + ">>>" + Colors.DEFAULT.color+ "|");
            else
                System.out.print("\t\t|   |");
        }
        System.out.println();
    }
    private void printLowerPartOfRow(int columnCount, int row) {
        for (int column = 0; column < columnCount; column++) {
            if (field.getTile(row, column).getTileState() == TileState.PLAYER1)
                System.out.print("\t\t" + backgroundP1 + "|___|"+Colors.DEFAULT.color);
            else if (field.getTile(row, column).getTileState() == TileState.PLAYER2)
                System.out.print("\t\t" + backgroundP2 + "|___|"+Colors.DEFAULT.color);
            else
                System.out.print("\t\t|___|");
        }
        System.out.println("\n");
    }
    private void printColumnHeader(int columnCount) {
        for (int column = 0; column < columnCount; column++)
            System.out.print(Colors.CYAN.color + "\t\t _" + (column+ 1) + "_ " + Colors.DEFAULT.color);
        System.out.println();
    }

    //main field input function
    private int handleFieldInput() {
        Pattern pattern = Pattern.compile("^\\d$");
        int input = 0, columnCount = field.getColumnCount();
        boolean isInputValid = false;
        Scanner scanner = new Scanner(System.in);

        do {
            printAskForFieldInput();
            String text = scanner.nextLine();
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                input = Integer.parseInt(matcher.group(0));
                if (input >= 0 && input <= columnCount)
                    isInputValid = true;
            }
            else {
                System.out.println(Colors.RED.color + "Invalid input!" + Colors.DEFAULT.color);
            }
        } while (!isInputValid);

        return input;
    }

    //print state of game functions
    private void draw() {
        System.out.println(Colors.CYAN.color + "Ooops, that's DRAW!" + Colors.DEFAULT.color);
    }
    private void decided() {
        if (field.getFieldState() != FieldState.DECIDED)
            return;
        if (field.getWinner() == Player.PLAYER1)
            System.out.println(colorP1 + nameP1 + Colors.CYAN.color + " has won!" + Colors.DEFAULT.color);
        else
            System.out.println(colorP2 + nameP2 + Colors.CYAN.color + " has won!" + Colors.DEFAULT.color);
    }
    private void exited() {
        System.out.println(Colors.CYAN.color + "The game was aborted..." + Colors.DEFAULT.color);
    }

    //get name functions
    private void getPlayersNames() {
        getFirstPlayerName();
        getSecondPlayerName();
    }
    private void getFirstPlayerName() {
        Scanner scanner = new Scanner(System.in);
        boolean isNameValid = false;

        do {
            System.out.print(Colors.CYAN.color + "Player 1, your name: ");
            nameP1 = scanner.nextLine();
            if (nameP1.replaceAll("\\s+","").length() == 0)
                System.out.println(Colors.RED.color + "Invalid input!");
            else if (nameP1.length() > 32)
                System.out.println(Colors.RED.color + "Your name can't be longer than 32 chars!");
            else
                isNameValid = true;
        } while (!isNameValid);
        nameP1 = nameP1.trim();
    }
    private void getSecondPlayerName() {
        Scanner scanner = new Scanner(System.in);
        boolean isNameValid = false;

        do {
            System.out.print(Colors.CYAN.color + "Player 2, your name: ");
            nameP2 = scanner.nextLine();
            if (nameP2.replaceAll("\\s+","").length() == 0)
                System.out.println(Colors.RED.color + "Invalid input!");
            else if (nameP2.length() > 32)
                System.out.println(Colors.RED.color + "Your name can't be longer than 32 chars!");
            else
                isNameValid = true;
        } while (!isNameValid);
        nameP2 = nameP2.trim();
    }

    //get players' colors functions
    private void getPlayersColors() {
        String[] colors ={Colors.BLACK.color, Colors.RED.color, Colors.GREEN.color, Colors.YELLOW.color,
                Colors.BLUE.color, Colors.PURPLE.color, Colors.WHITE.color};

        String[] backgrounds = {BackgroundColors.BLACK.color, BackgroundColors.RED.color,
                BackgroundColors.GREEN.color, BackgroundColors.YELLOW.color, BackgroundColors.BLUE.color,
                BackgroundColors.PURPLE.color, BackgroundColors.WHITE.color};

        printAllColors();

        int input1, input2;
        input1 = chooseColorInput(nameP1);
        input2 = chooseColorInput(nameP2);

        while (input2 == input1) {
            System.out.println(Colors.RED.color + "The color is already taken!" + Colors.DEFAULT.color);
            input2 = chooseColorInput(nameP2);
        }

        if (field.getCurrentPlayer() == Player.PLAYER1) {
            this.backgroundP1 = backgrounds[input1 - 1];
            this.colorP1 = colors[input1 - 1];
            this.backgroundP2 = backgrounds[input2 - 1];
            this.colorP2 = colors[input2 - 1];
        }
        else {
            this.backgroundP1 = backgrounds[input2 - 1];
            this.colorP1 = colors[input2 - 1];
            this.backgroundP2 = backgrounds[input1 - 1];
            this.colorP2 = colors[input1 - 1];
        }
    }
    private int chooseColorInput(String playerName) {
        Pattern pattern = Pattern.compile("^[1-7]$");
        String text;
        Scanner scanner = new Scanner(System.in);
        Matcher matcher;
        boolean isInputValid = false;

        do {
            System.out.print(Colors.CYAN.color + "Please, " + Colors.RED.color + playerName +
                    Colors.CYAN.color + " choose the color: " + Colors.DEFAULT.color);
            text = scanner.nextLine();
            matcher = pattern.matcher(text);
            if (matcher.find())
                isInputValid = true;
            else
                System.out.println(Colors.RED.color + "Wrong input! Choose again!" + Colors.DEFAULT.color);
        } while(!isInputValid);

        return Integer.parseInt(text);
    }

    //comment and rating functions
    private void commentGame() {
        playerCommentsGame(nameP1, colorP1);
        playerCommentsGame(nameP2, colorP2);
    }
    private void playerCommentsGame(String playerName, String playerColor) {
        if (getDecision(commentRequest(playerName, playerColor)))
            getComment(playerName, playerColor);
    }
    private void getComment(String playerName, String playerColor) {
        String text;
        Scanner scanner = new Scanner(System.in);
        boolean isInputValid = false;

        do {
            System.out.println(Colors.CYAN.color + "Please, " + playerColor + playerName + Colors.CYAN.color +
                    " write a comment: " + Colors.DEFAULT.color);
            text = scanner.nextLine();
            if (text.length() > 100)
                System.out.println(Colors.RED.color + "Your comment can't be longer than 100 chars!");
            else
                isInputValid = true;
        } while(!isInputValid);

        commentService.addComment(new Comment(playerName, "connectfour", text, new Date()));
    }

    private boolean getDecision(String request) {
        Pattern pattern = Pattern.compile("^[y|n]$");
        String text;
        Matcher matcher;
        Scanner scanner = new Scanner(System.in);
        boolean isInputValid = false;
        do {
            System.out.print(request);
            text = scanner.nextLine();
            matcher = pattern.matcher(text);
            if (matcher.find()) {
                isInputValid = true;
            }
            else {
                System.out.println(Colors.RED.color + "Invalid input!" + Colors.DEFAULT.color);
            }
        } while(!isInputValid);
        return matcher.group(0).charAt(0) == 'y';
    }
    private String droppingDiskRequest() {
        return Colors.CYAN.color + "Would you like to enable a dropping disk? (y/n) " + Colors.DEFAULT.color;
    }
    private String commentRequest(String playerName, String playerColor) {
        return (Colors.CYAN.color + "Would you like to leave a comment " + playerColor + playerName +
                Colors.CYAN.color + "? (y/n) " + Colors.DEFAULT.color);
    }
    private String savingGameRequest() {
        return Colors.CYAN.color + "Would you like to save a game? (y/n) " + Colors.DEFAULT.color;
    }
    private void commentsAndRatings() {
        List<Comment> commentList = commentService.getComments("connectfour");
        DateFormat dateFormat;
        int rating;
        if (commentList.size() != 0) {
            System.out.println(Colors.YELLOW_BOLD.color + "\n" +
                "█▀▀ █▀█ █▀▄▀█ █▀▄▀█ █▀▀ █▄░█ ▀█▀ █▀   ▄▀█ █▄░█ █▀▄   █▀█ ▄▀█ ▀█▀ █ █▄░█ █▀▀ █▀\n" +
                "█▄▄ █▄█ █░▀░█ █░▀░█ ██▄ █░▀█ ░█░ ▄█   █▀█ █░▀█ █▄▀   █▀▄ █▀█ ░█░ █ █░▀█ █▄█ ▄█\n" +
                Colors.DEFAULT.color);
            printAverageRating();
            for (Comment comment : commentList) {
                dateFormat = new SimpleDateFormat("dd.MM.yyyy H:mm");
                System.out.print(Colors.YELLOW.color + comment.getPlayer() + " [" + Colors.CYAN.color +
                        dateFormat.format(comment.getCommentedAt()) + Colors.YELLOW.color + "] " + Colors.DEFAULT.color);
                rating = ratingService.getRating("connectfour", comment.getPlayer());
                for (int i = 0; i < rating; i++)
                    System.out.print(Colors.YELLOW.color + "★" + Colors.DEFAULT.color);
                System.out.println();
                System.out.println(comment.getComment());
            }
        }
    }
    private void printAverageRating() {
        System.out.print(Colors.RED.color + "Average rating: ");
        int avgRating = ratingService.getAverageRating("connectfour");
        for (int i = 0; i < avgRating; i++)
            System.out.print(Colors.YELLOW.color + "★" + Colors.DEFAULT.color);
        System.out.println();
    }
    private void rateGame() {
        playerRatesGame(nameP1, colorP1);
        playerRatesGame(nameP2, colorP2);
    }
    private void playerRatesGame(String playerName, String playerColor) {
        Scanner scanner = new Scanner(System.in);
        Pattern pattern = Pattern.compile("^[1-5]$");
        boolean isInputValid = false;
        int input = 0;
        do {
            System.out.print(Colors.CYAN.color + "Please, " + playerColor + playerName + Colors.CYAN.color +
                    " rate the game (1-5): " + Colors.DEFAULT.color);
            String text = scanner.nextLine();
            Matcher matcher = pattern.matcher(text);
            if (matcher.find()) {
                input = Integer.parseInt(matcher.group(0));
                if (input >= 1 && input <= 5)
                    isInputValid = true;
            }
            else {
                System.out.println(Colors.RED.color + "Invalid input!" + Colors.DEFAULT.color);
            }
        } while (!isInputValid);
        ratingService.setRating(new Rating(playerName, "connectfour", input, new Date()));
    }

    //score functions
    private void hallOfFame() {
        List<Score> scoreList = scoreService.getTopScore("connectfour");
        if (scoreList == null)
            return;
        int listSize = scoreList.size();
        if (listSize == 0)
            return;

        System.out.println(Colors.YELLOW_BOLD.color +
                "\n\t\t\t\t\t█░█ ▄▀█ █░░ █░░   █▀█ █▀▀   █▀▀ ▄▀█ █▀▄▀█ █▀▀\n" +
                "\t\t\t\t\t█▀█ █▀█ █▄▄ █▄▄   █▄█ █▀░   █▀░ █▀█ █░▀░█ ██▄\n" + Colors.DEFAULT.color);
        DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy H:mm");
        for (int i = 0; i < listSize; i++) {
            System.out.println(Colors.CYAN_BOLD.color + (i + 1) + ". " + Colors.DEFAULT.color +
                    Colors.YELLOW.color + scoreList.get(i).getPlayer() + Colors.CYAN.color +
                    " [" + Colors.YELLOW.color + dateFormat.format(scoreList.get(i).getPlayedAt()) +
                    Colors.CYAN.color + "]" + Colors.RED_BOLD.color + " " + scoreList.get(i).getPoints() +
                    Colors.DEFAULT.color);
        }
        System.out.println();
    }
    private void printScore() {
        System.out.println();
        System.out.println(Colors.RED.color +
                "\t\t\t\t\t\t█▀▀ ▄▀█ █▀▄▀█ █▀▀   █▀ █▀▀ █▀█ █▀█ █▀▀\n" +
                "\t\t\t\t\t\t█▄█ █▀█ █░▀░█ ██▄   ▄█ █▄▄ █▄█ █▀▄ ██▄\n" +
                "\t\t\t\t\t\t--------------------    ----------------------");
        System.out.println(colorP1 + "\t\t\t\t\t\t" + nameP1 + " " + Colors.CYAN.color + field.getScorePlayer1());
        System.out.println(colorP2 + "\t\t\t\t\t\t" + nameP2 + " " + Colors.CYAN.color + field.getScorePlayer2() + Colors.DEFAULT.color);
        System.out.println();
    }

    private void showDroppingDisk(int droppingDiskColumn) {
        int rowCount = field.getRowCount();
        int columnCount = field.getColumnCount();
        int droppingDiskRow = 0;

        while(droppingDiskRow < rowCount - 1 &&
                field.getTile(droppingDiskRow + 1, droppingDiskColumn).getTileState() == TileState.EMPTY) {
            for (int row = 0; row < rowCount; row++) {
                printUpperPartOfRow(columnCount);
                printMiddlePartOfDroppingDisk(row, droppingDiskRow, droppingDiskColumn);
                printLowerPartOfDroppingDisk(row, droppingDiskRow, droppingDiskColumn);
            }
            delay();
            System.out.println();
            droppingDiskRow++;
        }
    }
    private void printMiddlePartOfDroppingDisk(int row, int diskRow, int diskColumn) {
        int columnCount = field.getColumnCount();
        for (int column = 0; column < columnCount; column++) {
            if (column == diskColumn && row == diskRow && field.getTile(diskRow, diskColumn).getTileState()
                    == TileState.EMPTY) {
                if (field.getCurrentPlayer() == Player.PLAYER1)
                    System.out.print("\t\t" + backgroundP1 + "|   |" + Colors.DEFAULT.color);
                else
                    System.out.print("\t\t" + backgroundP2 + "|   |" + Colors.DEFAULT.color);
            }
            else if (field.getTile(row, column).getTileState() == TileState.PLAYER1)
                System.out.print("\t\t" + backgroundP1 + "|   |" + Colors.DEFAULT.color);
            else if (field.getTile(row, column).getTileState() == TileState.PLAYER2)
                System.out.print("\t\t" + backgroundP2 + "|   |" + Colors.DEFAULT.color);
            else
                System.out.print("\t\t|   |");
        }
        System.out.println();
    }
    private void printLowerPartOfDroppingDisk(int row, int diskRow, int diskColumn) {
        int columnCount = field.getColumnCount();
        for (int column = 0; column < columnCount; column++) {
            if (column == diskColumn && row == diskRow && field.getTile(diskRow, diskColumn).getTileState()
                    == TileState.EMPTY) {
                if (field.getCurrentPlayer() == Player.PLAYER1)
                    System.out.print("\t\t" + backgroundP1 + "|___|" + Colors.DEFAULT.color);
                else
                    System.out.print("\t\t" + backgroundP2 + "|___|" + Colors.DEFAULT.color);
            } else if (field.getTile(row, column).getTileState() == TileState.PLAYER1)
                System.out.print("\t\t" + backgroundP1 + "|___|" + Colors.DEFAULT.color);
            else if (field.getTile(row, column).getTileState() == TileState.PLAYER2)
                System.out.print("\t\t" + backgroundP2 + "|___|" + Colors.DEFAULT.color);
            else
                System.out.print("\t\t|___|");
        }
        System.out.println("\n");
    }

    //delay function
    private void delay() {
        try {
            Thread.sleep(250);
        } catch (InterruptedException e) {
            throw new RuntimeException("There has been an error with delaying the game...");
        }
    }

    public void setField(Field field) {
        this.field = field;
    }
}
