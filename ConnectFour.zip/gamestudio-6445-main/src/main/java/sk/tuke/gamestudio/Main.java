package sk.tuke.gamestudio;

import sk.tuke.gamestudio.connectfour.consoleui.ConsoleUI;
import sk.tuke.gamestudio.connectfour.core.Field;
import sk.tuke.gamestudio.connectfour.core.Player;

public class Main {
    public static void main(String[] args) {
        Field field = new Field(6, 7, 4, Player.PLAYER1, true);
        ConsoleUI consoleUI = new ConsoleUI(field);
        consoleUI.play();
    }
}
