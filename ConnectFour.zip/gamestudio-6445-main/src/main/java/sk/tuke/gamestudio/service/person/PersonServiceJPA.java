package sk.tuke.gamestudio.service.person;

import sk.tuke.gamestudio.entity.Person;
import sk.tuke.gamestudio.service.score.ScoreException;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

@Transactional
public class PersonServiceJPA implements PersonService {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void registerPerson(String login, String password, String game) throws ScoreException {
        entityManager.persist(new Person(login, password, game));
    }

    @Override
    public Person getPerson(String login, String game) throws ScoreException {
        try {
            return (Person) entityManager.createNamedQuery("Person.getPerson")
                    .setParameter("game", game)
                    .setParameter("login", login)
                    .getSingleResult();
            }
            catch (NoResultException noResultException) {
                return null;
            }
    }

    @Override
    public void reset() throws ScoreException {
        entityManager.createNamedQuery("Person.resetPersons").executeUpdate();
    }
}
