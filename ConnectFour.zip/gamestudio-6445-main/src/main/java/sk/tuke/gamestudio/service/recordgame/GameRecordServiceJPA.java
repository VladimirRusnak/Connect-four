package sk.tuke.gamestudio.service.recordgame;

import sk.tuke.gamestudio.entity.GameRecord;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.transaction.Transactional;
import java.util.Date;
import java.util.List;

@Transactional
public class GameRecordServiceJPA implements GameRecordService {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public void save(GameRecord gameRecord) throws GameRecordException {
        entityManager.persist(gameRecord);
    }

    @Override
    public List<GameRecord> load(String game, String player1, String player2) throws GameRecordException {
        return (List<GameRecord>) entityManager.createNamedQuery("GameRecord.getRecordsForPlayers")
                        .setParameter("game", game)
                        .setParameter("player1", player1)
                        .setParameter("player2", player2)
                        .getResultList();
    }

    @Override
    public void deleteSave(String game, String player1, String player2, Date recordedOn) {
        entityManager.createNamedQuery("GameRecord.deleteGameRecord")
                .setParameter("game", game)
                .setParameter("player1", player1)
                .setParameter("player2", player2)
                .setParameter("recordedOn",recordedOn, TemporalType.TIMESTAMP)
                .executeUpdate();
    }

    @Override
    public void reset(String game) throws GameRecordException {
        entityManager.createNamedQuery("GameRecord.resetGameRecord")
                        .setParameter("game", game)
                        .executeUpdate();
    }
}
