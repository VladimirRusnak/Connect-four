package sk.tuke.gamestudio.service.score;

import sk.tuke.gamestudio.entity.Score;
import sk.tuke.gamestudio.service.GameStudioException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ScoreServiceJDBC implements ScoreService{
    public static final String JDBC_URL = "jdbc:postgresql://localhost:5432/gamestudio";
    public static final String JDBC_USER = "postgres";
    public static final String JDBC_PASSWORD = "postgres";
    public static final String DELETE_STATEMENT = "DELETE FROM Score";
    public static final String SELECT_STATEMENT = "SELECT player, game, points, played_at" +
            " FROM Score WHERE game = ? ORDER BY points DESC LIMIT 10;";

    public static final String INSERT_STATEMENT = "INSERT INTO Score (player, game, points, played_at)" +
            " VALUES (?, ?, ?, ?);";

    @Override
    public void addScore(Score score) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(INSERT_STATEMENT);
        ) {
            statement.setString(1, score.getPlayer());
            statement.setString(2, score.getGame());
            statement.setInt(3, score.getPoints());
            statement.setTimestamp(4, new Timestamp(score.getPlayedAt().getTime()));
            statement.executeUpdate();
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public List<Score> getTopScore(String game) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(SELECT_STATEMENT);
        )
        {
            statement.setString(1, game);
            try (ResultSet resultSet = statement.executeQuery()){
                ArrayList<Score> scores = new ArrayList<>();
                while (resultSet.next()) {
                    scores.add(new Score(resultSet.getString(1), resultSet.getString(2),
                            resultSet.getInt(3), resultSet.getTimestamp(4)));
                }
                return scores;
            }
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public void reset() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement statement = connection.createStatement())
        {
            statement.executeUpdate(DELETE_STATEMENT);
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }
}
