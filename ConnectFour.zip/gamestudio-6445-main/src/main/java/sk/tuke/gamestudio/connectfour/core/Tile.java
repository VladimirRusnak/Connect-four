package sk.tuke.gamestudio.connectfour.core;

import java.io.Serializable;

public class Tile implements Serializable {
    private TileState tileState;

    Tile() {
        tileState = TileState.EMPTY;
    }

    void setTileState(TileState tileState) {
        this.tileState = tileState;
    }

    public TileState getTileState() {
        return tileState;
    }
}
