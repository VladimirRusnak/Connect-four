package sk.tuke.gamestudio.connectfour.core;

public enum TileState {
    EMPTY, PLAYER1, PLAYER2, ROTL, ROTR
}
