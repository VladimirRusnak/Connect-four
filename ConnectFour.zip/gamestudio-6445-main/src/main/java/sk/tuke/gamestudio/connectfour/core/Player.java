package sk.tuke.gamestudio.connectfour.core;

public enum Player {
    PLAYER1, PLAYER2
}
