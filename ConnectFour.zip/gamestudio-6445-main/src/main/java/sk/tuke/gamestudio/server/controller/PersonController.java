package sk.tuke.gamestudio.server.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;
import sk.tuke.gamestudio.entity.Person;
import sk.tuke.gamestudio.service.person.PersonService;
import sk.tuke.gamestudio.service.score.ScoreService;

@Controller
@Scope(WebApplicationContext.SCOPE_SESSION)
public class PersonController {
    @Autowired
    private PersonService personService;
    private Person person1, person2;
    private int whichPerson = 1;
    private boolean canBeRegistered = true, canBeLogged = true;

    @RequestMapping("/")
    public String index(Model model) {
        return "index";
    }

    @RequestMapping("/get_players")
    public String getUsers() {
        return "get_players";
    }

    @RequestMapping("/register")
    public String register(String login, String password) {
        if (login == null || login.length() == 0 || password == null || password.length() == 0) {
            canBeRegistered = false;
            return "redirect:/get_players";
        }
        canBeRegistered = true;
        Person comparePerson = personService.getPerson(login, "connectfour");
        if (whichPerson == 1) {
            if (comparePerson != null) {
                canBeRegistered = false;
            } else {
                personService.registerPerson(login, password, "connectfour");
                person1 = personService.getPerson(login, "connectfour");
                canBeLogged = true;
                canBeRegistered = true;
                whichPerson = 2;
            }
            return "redirect:/get_players";
        }
        else {
            if (comparePerson != null) {
                canBeRegistered = false;
                return "redirect:/get_players";
            } else {
                personService.registerPerson(login, password, "connectfour");
                person2 = personService.getPerson(login, "connectfour");
                canBeLogged = true;
                canBeRegistered = true;
                return "redirect:/";
            }
        }
    }


    @RequestMapping("/login")
    public String login(String login, String password) {
        if (login == null || login.length() == 0 || password == null || password.length() == 0) {
            canBeLogged = false;
            return "redirect:/get_players";
        }
        Person comparePerson = personService.getPerson(login, "connectfour");
        if (whichPerson == 1) {
            if (comparePerson != null && password.equals(comparePerson.getPassword())) {
                canBeLogged = true;
                canBeRegistered = true;
                person1 = comparePerson;
                whichPerson = 2;
            } else {
                canBeLogged = false;
            }
            return "redirect:/get_players#logIn";
        }
        else {
            if (comparePerson != null && password.equals(comparePerson.getPassword())) {
                canBeLogged = true;
                canBeRegistered = true;
                person2 = comparePerson;
                return "redirect:/";
            } else {
                canBeLogged = false;
                return "redirect:/get_players#logIn";
            }
        }
    }

    @RequestMapping("/logout")
    public String logout() {
        whichPerson = 1;
        person1 = null;
        person2 = null;
        return "redirect:/";
    }

    public Person getPerson1() {
        return person1;
    }

    public Person getPerson2() {
        return person2;
    }

    public boolean isLogged() {
        return person1 != null && person2 != null;
    }

    public boolean isSinglePlayer() {
        return person1 == person2;
    }

    public int getWhichPerson() {
        return whichPerson;
    }

    public boolean cannotBeRegistered() {
        return canBeRegistered;
    }

    public boolean cannotBeLogged() {
        return canBeLogged;
    }

    public PersonService getPersonService() {
        return personService;
    }
}
