package sk.tuke.gamestudio.connectfour.core;

import java.io.*;
import java.util.Base64;

public class Serializator {

    public String serialize(Serializable serializable) {
        try (
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream))
        {
            objectOutputStream.writeObject(serializable);
            return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Object deserialize(String serialized) {
        try (
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
                        Base64.getDecoder().decode(serialized));
                ObjectInputStream objectInputStream = new ObjectInputStream(byteArrayInputStream))
        {
            return objectInputStream.readObject();
        } catch (IOException | ClassNotFoundException e)  {
            throw new RuntimeException(e);
        }
    }
}
