package sk.tuke.gamestudio;

import sk.tuke.gamestudio.entity.Score;
import sk.tuke.gamestudio.service.score.ScoreService;
import sk.tuke.gamestudio.service.score.ScoreServiceJDBC;

import java.util.Date;
import java.util.List;

public class TestJDBC {
    public static void main(String[] args) throws Exception {
        ScoreService service = new ScoreServiceJDBC();
        service.reset();
        service.addScore(new Score("vlado", "connectfour", 105, new Date()));
        List<Score> scores = service.getTopScore("connectfour");
        System.out.println(scores);
    }
}
