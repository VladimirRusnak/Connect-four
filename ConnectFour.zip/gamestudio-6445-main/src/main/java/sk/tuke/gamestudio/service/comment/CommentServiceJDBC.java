package sk.tuke.gamestudio.service.comment;

import sk.tuke.gamestudio.entity.Comment;
import sk.tuke.gamestudio.service.GameStudioException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CommentServiceJDBC implements CommentService {
    public static final String JDBC_URL = "jdbc:postgresql://localhost:5432/gamestudio";
    public static final String JDBC_USER = "postgres";
    public static final String JDBC_PASSWORD = "postgres";
    public static final String DELETE_STATEMENT = "DELETE FROM Comment";
    public static final String SELECT_STATEMENT = "SELECT player, game, comment, commented_at" +
            " FROM Comment WHERE game = ? ORDER BY commented_at DESC LIMIT 5;";
    public static final String INSERT_STATEMENT = "INSERT INTO Comment (player, game, comment, commented_at)" +
            " VALUES (?, ?, ?, ?);";

    @Override
    public void addComment(Comment comment) throws CommentException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(INSERT_STATEMENT);
        ) {
            statement.setString(1, comment.getPlayer());
            statement.setString(2, comment.getGame());
            statement.setString(3, comment.getComment());
            statement.setTimestamp(4, new Timestamp(comment.getCommentedAt().getTime()));
            statement.executeUpdate();
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public List<Comment> getComments(String game) throws CommentException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             PreparedStatement statement = connection.prepareStatement(SELECT_STATEMENT);
        )
        {
            statement.setString(1, game);
            try (ResultSet resultSet = statement.executeQuery()){
                ArrayList<Comment> comments = new ArrayList<>();
                while (resultSet.next()) {
                    comments.add(new Comment(resultSet.getString(1), resultSet.getString(2),
                            resultSet.getString(3), resultSet.getTimestamp(4)));
                }
                return comments;
            }
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }

    @Override
    public void reset() throws CommentException {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
             Statement statement = connection.createStatement())
        {
            statement.executeUpdate(DELETE_STATEMENT);
        }
        catch (SQLException e) {
            throw new GameStudioException(e);
        }
    }
}
