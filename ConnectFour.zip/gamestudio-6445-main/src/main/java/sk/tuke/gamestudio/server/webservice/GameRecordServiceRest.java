package sk.tuke.gamestudio.server.webservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import sk.tuke.gamestudio.entity.GameRecord;
import sk.tuke.gamestudio.service.recordgame.GameRecordService;

import java.util.List;

@RestController
@RequestMapping("/api/gamerecord")
public class GameRecordServiceRest {

    @Autowired
    private GameRecordService gameRecordService;

    @GetMapping("/{game}/{player1}/{player2}")
    public List<GameRecord> load(@PathVariable String game, @PathVariable String player1, @PathVariable String player2) {
        return gameRecordService.load(game, player1, player2);
    }

    @PostMapping
    public void save(@RequestBody GameRecord gameRecord) {
        gameRecordService.save(gameRecord);
    }
}
