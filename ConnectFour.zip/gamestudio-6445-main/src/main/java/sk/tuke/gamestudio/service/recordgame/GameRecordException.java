package sk.tuke.gamestudio.service.recordgame;

public class GameRecordException extends RuntimeException {
    public GameRecordException(String message) {
        super(message);
    }
    public GameRecordException(String message, Throwable cause) {
        super(message, cause);
    }
}
