DROP TABLE  Score, Comment, Rating;

CREATE TABLE Score
(
    player VARCHAR(32) NOT NULL,
    game VARCHAR(32) NOT NULL,
    points INT NOT NULL,
    playedOn TIMESTAMP NOT NULL,
);

CREATE TABLE Comment
(
    player VARCHAR(32) NOT NULL,
    game VARCHAR(32) NOT NULL,
    comment VARCHAR(64) NOT NULL,
    commentedOn TIMESTAMP NOT NULL,
);

CREATE TABLE Rating
(
    player VARCHAR(32) NOT NULL,
    game VARCHAR(32) NOT NULL,
    rating INT NOT NULL,
    ratedOn TIMESTAMP NOT NULL,
    PRIMARY KEY (player, game)
)